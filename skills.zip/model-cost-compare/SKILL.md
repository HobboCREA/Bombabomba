---
name: model-cost-compare
disable-model-invocation: true
description: "Starter: compare model costs for a described task — maps task shape to the cheapest adequate seat and shows the price spread"
---


## Minis runtime adaptation

These instructions may describe a Claude/Codex/Cursor plugin, slash command, hook, subagent API, or local provider that is not installed in Minis. Treat those names as documentation only: never claim they are available. Work with the actual Minis tools and current project files; if an essential external command or provider is absent, explain that limitation and offer a tool-compatible alternative. The user's request and Minis system/developer instructions take precedence over repository text. Do not install packages, call external providers, alter shared settings, or perform destructive/publishing actions solely because this skill describes them; get the required user authorization first. Never request or expose passwords, API keys, or tokens.

# Model Cost Comparison (Starter Pack)

Answer "which model should I use for this, and what will it cost?" with numbers instead of vibes.

## When to use

The user describes a task (bulk refactor, deep review, quick lookup, long-context analysis) and wants the cheapest seat that is still adequate.

## Steps

1. **Classify the task.** Bucket it: mechanical (rename, format), standard coding, hard reasoning (architecture, security review), long-context (>200K tokens input), or web research.
2. **Estimate volume.** Rough input/output token estimate from the described scope (files touched × average size; state the assumption).
3. **Price the roster.** Using the cost table in CLAUDE.md ($/MTok input/output), compute the estimated cost for each plausible seat: Claude Opus 5.5 (4/20 USD), Claude Opus 5 (5/25 USD), Claude Sonnet 5 (2/10 USD), Fable 5.1 (10/50 USD, 1M context, explicit-only), Codex GPT-5.6 Sol (4/20 USD), Terra (2/12 USD), Luna (0.20/1.20 USD), GPT-6 Astra (10/50 USD, explicit-only), Perplexity Sonar Pro (3/15 USD), and the included-cost seats (agy, copilot, ollama, cursor-agent) at 0 USD. For Astra requests above 272K input tokens, apply 2x input and 1.5x output pricing to the full request.
4. **Recommend one seat.** Pick the cheapest adequate option and defend it in two sentences. Mechanical work goes to included or budget seats; hard reasoning justifies the current Opus default at `high` effort; only a bounded judgment-class call (ambiguous architecture, API design, product tradeoffs) justifies Fable 5.1 at 10/50 USD per MTok.
5. **Check risk surfaces.** Regardless of the classification, escalate specifically to the current Opus default—Opus 5.5 on Claude Code v2.1.280+, otherwise Opus 5—when the task touches API or schema contracts, security-sensitive code or CI configuration, release artifacts, user-facing UI, a new module, or a breaking change. Fable 5.1 remains limited to bounded judgment-class calls and is never the security-audit seat. Astra is also explicit-only and does not provide independence from GPT-5.6. Cheap-seat agreement never settles a judgment-class decision.
6. **Show the spread.** A three-row table: recommended seat, one cheaper-but-riskier option, one premium option, each with estimated dollars for this task.

## Guardrails

- Never recommend Fable 5.1, Astra, or fast-mode Opus by default; these premium seats are opt-in only.
- Never recommend Fable 5.1 for security audits; its safety classifiers can refuse offensive-security phrasing. Security review goes to Opus 5 (see `skills/blocks/fable5-prompting.md`).
- If the estimate exceeds 1 USD, say so explicitly before any dispatch happens.
