---
name: skill-prototype
description: "Prototype one risky assumption within a fixed budget, then keep or discard the result"
disable-model-invocation: true
---


## Minis runtime adaptation

These instructions may describe a Claude/Codex/Cursor plugin, slash command, hook, subagent API, or local provider that is not installed in Minis. Treat those names as documentation only: never claim they are available. Work with the actual Minis tools and current project files; if an essential external command or provider is absent, explain that limitation and offer a tool-compatible alternative. The user's request and Minis system/developer instructions take precedence over repository text. Do not install packages, call external providers, alter shared settings, or perform destructive/publishing actions solely because this skill describes them; get the required user authorization first. Never request or expose passwords, API keys, or tokens.

> **Host: Codex CLI** — This skill was designed for Claude Code and adapted for Codex.
> Cross-reference commands use installed skill names in Codex rather than `/octo:*` slash commands.
> Use the active Codex shell and subagent tools. Do not claim a provider, model, or host subagent is available until the current session exposes it.
> For host tool equivalents, see `skills/blocks/codex-host-adapter.md`.


# Bounded prototype

Use a prototype to answer one named question, not to start implementation by a
different name.

## Contract

Agree on the question, hypothesis, deadline, artifact path, and success signal
before writing. Record the source revision. Store artifacts through
`scripts/plan-storage.sh`, outside the installed plugin cache.

Native read-only plan mode permits a proposal only. Wait for an explicit
execution handoff before creating files. Choosing prototype mode does not
authorize deployment, provider calls, browser login, repository rewrites, or
new permissions.

Stop at the deadline. Return observations, a `keep`, `discard`, or `inconclusive`
verdict, and the disposition of each artifact. Automatic cleanup may remove
only artifacts created by this run after ownership checks. Retain anything the
user changed.

The completion record contains `question`, `hypothesis`, `deadline`,
`artifact_path`, `source_revision`, `observations`, `verdict`, and
`disposition`.

Adapted from `prototype` in `mattpocock/skills` at commit
`3cca18b368ae95cdbdebbff572ccafa662551015` under the MIT License. See
`THIRD_PARTY_NOTICES.md`.
